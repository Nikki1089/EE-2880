# FIXED

uart_data.obj: ../uart_data.c

../uart_data.c:

